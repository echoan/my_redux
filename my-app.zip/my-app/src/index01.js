import React from 'react';
import ReactDOM from 'react-dom';
import App01 from './App01';
ReactDOM.render(<App01 />, document.getElementById('root'));