export const CHANGE_TEXT = "change_Text"
export const ADD_TEXT = "add_Text"
export const DEL_TEXT = "del_Text"