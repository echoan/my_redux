import React from 'react';
import ReactDOM from 'react-dom';
import App04 from './App04';
ReactDOM.render(<App04 />, document.getElementById('root'));
