export const CHANGE_TEXT = "change_Text"
export const ADD_TEXT = "add_Text"
export const DEL_TEXT = "del_Text"
export const GET_DATA = "get_Data"