import React from 'react';
import ReactDOM from 'react-dom';
import App02 from './App02';
ReactDOM.render(<App02 />, document.getElementById('root'));
